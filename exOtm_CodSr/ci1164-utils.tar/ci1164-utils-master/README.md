# CI1164 - Utils

Funções e bibliotecas de uso genérico para a disciplina CI1164 (DINF/UFPR)

* **gnuplot:** documentação e modelos de scripts para uso de gnuplot.
* **sislin:** funções básicas de manipulação de matrizes e Sistemas Lineares
* **utils:** funções utilitárias diversas: timestamp, geradores de
         números pseudo-aleatórios, etc.

